<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BussinessType extends Model
{
    protected $fillable = [
        'name_ar', 'name_en'
    ];
   protected $casts = [
        'id' => 'integer',
    ];
    public function Client()
    {
        return $this->hasMany(Client::class,'id','businessTypeId');

    }//end of Client


}
